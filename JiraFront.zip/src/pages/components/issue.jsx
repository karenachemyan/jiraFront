import React, { useEffect } from 'react';
import { Button, Form, Input } from 'antd';

import { useLocation, useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';
import TextArea from 'antd/es/input/TextArea';
import { createIssueThunk, updateIssueThunk } from '../../store/thunks/issue';
import { useForm } from 'antd/es/form/Form';


const Issue = () => {
  const location = useLocation();
  const { id } = useParams();
  const [form] = Form.useForm();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isIssueCreated = useSelector((state) => {
    return state.issues.isCreated;
  })
  const isIssueUpdated = useSelector((state) => {
    return state.issues.isUpdated;
  })


  const onFinish = (values) => {
    const data = {
      ...values,
      type: location.state?.type ? location.state?.type : void 0,  
     
    }
    const updateData={
      ...values,
       pid:location.state.pid,
       id:id
    }
   
   id ? dispatch(updateIssueThunk(updateData)) : dispatch(createIssueThunk(data))
  };

  useEffect(() => {
    if (isIssueCreated || isIssueUpdated)
      navigate(-1)
  }, [isIssueCreated,isIssueUpdated])

  useEffect(()=>{
    if(id)
    form.setFieldsValue({
      summary: location.state.summary,
      description: location.state.description
     
  });

  },[id])

  return (
    <>
      <h2>{id ? "Update Issue": "Create Issue"}</h2>
      <div className="buttons">
                <Button
                    onClick={() => {
                        navigate(-1)
                    }}>Back to Issues</Button>
             
            </div>
      <Form
        name="basic"
        labelCol={{ span: 24 }}
        wrapperCol={{ span: 24 }}
        style={{ maxWidth: 1000, margin: "0 auto", display: "flex", flexDirection: "column", justifyContent: "center" }}
        initialValues={{ remember: true }}
        form={form}
        onFinish={onFinish}
        autoComplete="off"
      >
        <Form.Item
          label="Summary"
          name="summary"
          rules={[{ required: true, message: 'Please input summary!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Description"
          name="description"
          rules={[{ required: true, message: 'Please input description!' }]}
        >
          <TextArea />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit">
          {id ? "Update"  : "Add Issue" }
          </Button>
        </Form.Item>
      </Form>
    </>
  )
}

export default Issue;